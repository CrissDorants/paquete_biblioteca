Manejo de Errores
=================

Posibles errores y soluciones:

- **Error de importación**:
  - Mensaje: `ModuleNotFoundError: No module named 'validador_entrada'`
  - Solución: Asegúrate de instalar la biblioteca con `pip install validador_entrada`.

- **Tipo de validación incorrecto**:
  - Mensaje: `TypeError: Tipo de validación no soportado`
  - Solución: Usa `"numero"`, `"correo"` o `"texto"` como parámetros.

- **Campo vacío**:
  - Mensaje: `"Entrada no válida"`
  - Solución: Asegúrate de ingresar un valor en el campo de texto.
