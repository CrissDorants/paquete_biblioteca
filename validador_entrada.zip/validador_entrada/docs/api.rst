Referencia de la API
====================

.. automodule:: validador_entrada.validador
   :members:
