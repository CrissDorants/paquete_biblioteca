Validador de Entrada
====================

Bienvenido a la documentación de **Validador de Entrada**, un paquete en Python basado en Tkinter para validar entradas en interfaces gráficas.

Características:
- Validación de números, correos electrónicos y texto.
- Fácil integración en aplicaciones Tkinter.
- Mensajes visuales para mejorar la experiencia del usuario.

.. toctree::
   :maxdepth: 2
   :caption: Contenido:

   installation
   usage
   errors
   api

