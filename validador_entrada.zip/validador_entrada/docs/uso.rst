Ejemplo de Uso
==============

Aquí tienes un ejemplo de cómo usar **Validador de Entrada** en una aplicación Tkinter:

.. code-block:: python

    import tkinter as tk
    from validador_entrada.validador import ValidadorEntrada

    root = tk.Tk()
    validador = ValidadorEntrada(root, "correo")
    root.mainloop()
