Instalación
===========

Para instalar **Validador de Entrada**, usa:

.. code-block:: sh

    pip install validador_entrada

Dependencias:
- Python 3.x
- Tkinter (incluido en la instalación estándar de Python)
